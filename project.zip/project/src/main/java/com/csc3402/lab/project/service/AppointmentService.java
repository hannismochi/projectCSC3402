package com.csc3402.lab.project.service;

import com.csc3402.lab.project.model.Appointment;

import java.util.List;

public interface AppointmentService {

    void saveAppointment(Appointment appointment);

    List<Appointment> getAllAppointment();
}
