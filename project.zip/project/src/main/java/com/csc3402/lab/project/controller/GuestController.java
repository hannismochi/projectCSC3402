package com.csc3402.lab.project.controller;

import com.csc3402.lab.project.model.Certificate;
import com.csc3402.lab.project.model.Donor;
import com.csc3402.lab.project.repository.CertificateRepository;
import com.csc3402.lab.project.repository.DonorRepository;
import com.csc3402.lab.project.service.CertificateService;
import com.csc3402.lab.project.service.DonorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/")
public class GuestController {

    @Autowired
    private CertificateService certificateService;

    @Autowired
    private DonorService donorService;


    @GetMapping("/index")
    public String home() {
        return "index";
    }

    @GetMapping("/")
    public String redirectToHome() {
        return "redirect:/index";
    }

    @GetMapping("/signin")
    public String showSignInForm(Model model) {
        model.addAttribute("donor", new Donor());
        return "GuestLogin";
    }

    @PostMapping("/signin")
    public String signIn(@Valid @ModelAttribute("donor") Donor donor, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "GuestLogin";
        }

        Donor existingDonor = donorService.findByEmail(donor.getEmail());
        if (existingDonor != null && existingDonor.getPassword().equals(donor.getPassword())) {
            model.addAttribute("donor", existingDonor);
            return "GuestAfterLogin";
        }

        result.rejectValue("password", "error.donor", "Invalid email or password");
        return "GuestLogin";
    }

    @GetMapping("/signup")
    public String showSignUpForm(Model model) {
        model.addAttribute("donor", new Donor());
        return "register";
    }

    @PostMapping("/signup")
    public String saveDonor(@Valid Donor donor, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "register";
        }
        donorService.saveDonor(donor);
        model.addAttribute("success", true);
        return "redirect:/signin";
    }

    @GetMapping("/main")
    public String showMainPage() {
        return "GuestAfterLogin";
    }

    @GetMapping("/certificate")
    public String showCertificate(Model model) {
        List<Certificate> certificate = certificateService.listAllCertificates();
        model.addAttribute("certificate" , certificate);
        return "GuestCertificate";
    }

    @GetMapping("/logout")
    public String empLogout() {
        return "redirect:/signin?logout";
    }

}
