package com.csc3402.lab.project.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "patient")
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long patient_id;
    private String name;
    private String DOB;
    private int phone;
    private String bloodGroup;
    private String cause;

    @ManyToOne
    @JoinColumn(name = "bloodbank_id")
    private BloodBank bloodBank;

    public Patient() {
    }

    public Patient(Long patient_id, String name, String DOB, int phone, String bloodGroup, String cause, BloodBank bloodBank) {
        this.patient_id = patient_id;
        this.name = name;
        this.DOB = DOB;
        this.phone = phone;
        this.bloodGroup = bloodGroup;
        this.cause = cause;
        this.bloodBank = bloodBank;
    }

    public Long getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(Long patient_id) {
        this.patient_id = patient_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public BloodBank getBloodBank() {
        return bloodBank;
    }

    public void setBloodBank(BloodBank bloodBank) {
        this.bloodBank = bloodBank;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "patient_id=" + patient_id +
                ", name='" + name + '\'' +
                ", DOB='" + DOB + '\'' +
                ", phone=" + phone +
                ", bloodGroup='" + bloodGroup + '\'' +
                ", cause='" + cause + '\'' +
                ", bloodBank=" + bloodBank +
                '}';
    }
}
