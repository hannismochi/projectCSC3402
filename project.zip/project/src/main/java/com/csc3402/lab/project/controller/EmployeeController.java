package com.csc3402.lab.project.controller;

import com.csc3402.lab.project.dto.DonorDto;
import com.csc3402.lab.project.model.*;
import com.csc3402.lab.project.service.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private CertificateService certificateService;

    @Autowired
    private DonorService donorService;

    @Autowired
    private BloodBankService bloodBankService;

    @Autowired
    private PatientService patientService;

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/emp-signin")
    public String showSignInForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "BBLogin";
    }

    @PostMapping("/emp-signin")
    public String signIn(@Valid @ModelAttribute("employee") Employee employee, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "BBLogin";
        }

        Employee existingEmployee = employeeService.findByEmail(employee.getEmail());
        if (existingEmployee != null && existingEmployee.getPassword().equals(employee.getPassword())) {
            model.addAttribute("employee", existingEmployee);
            return "BBAfterLogin";
        }

        result.rejectValue("password", "error.employee", "Invalid email or password");
        return "BBLogin";
    }

    @GetMapping("/emp-main")
    public String showMain() {
        return "BBAfterLogin";
    }

    @GetMapping("/donors")
    public String showDonorData(Model model) {
        List<DonorDto> donors = donorService.getDonorDto();
        System.out.println("Donors: " + donors); // Debugging line
        model.addAttribute("donors", donors);
        return "BBDonorData";
    }

    @GetMapping("/donors/{id}")
    public String showDonor(@PathVariable Long id, Model model) {
        Donor donor = donorService.getDonor(id);
        model.addAttribute("donor", donor);
        return "BBDonorData";
    }

    @GetMapping("/donors/edit/{id}")
    public String editDonor(@PathVariable("id") Long id, Model model) {
        Donor donor = donorService.getDonor(id);
        model.addAttribute("donor", donor);
        List<Certificate> certificate = certificateService.listAllCertificates();
        model.addAttribute("certificate", certificate);

        return "BBDonorEdit";
    }

    @PostMapping("/donors/edit/{id}")
    public String saveDonors(@PathVariable("id") Long id, @ModelAttribute("donor") DonorDto donorDto, Model model) {
        Donor existingDonor = donorService.getDonor(id);
        if (existingDonor == null) {
            model.addAttribute("errorMessage", "Donor not found");
            return "redirect:/BBPatientEdit";
        }
        // Update the existing patient with the new details
        existingDonor.setName(donorDto.getName());
        existingDonor.setEmail(donorDto.getEmail());
        existingDonor.setDOB(donorDto.getDOB());
        existingDonor.setMedCondi(donorDto.getMedCondi());
        existingDonor.setBloodGroup(donorDto.getBloodGroup());
        existingDonor.setEmergencyPhone(donorDto.getEmergencyPhone());
        existingDonor.setRelationshipDonor(donorDto.getRelationshipDonor());
        // Save the updated patient
        donorService.saveDonor(existingDonor);
        return "redirect:/donors"; // Redirect to the list of patients or another appropriate page
    }

    @GetMapping("/donors/delete/{id}")
    public String deleteDonor(@PathVariable("id") Long id) {
        donorService.deleteDonor(id);
        return "redirect:/donors";
    }

    @GetMapping("/patients")
    public String getBBPatientData(Model model) {
        List<Patient> patients = patientService.getAllPatient();
        model.addAttribute("patients", patients);
        return "BBPatientData";
    }

    @GetMapping("/patients/edit/{id}")
    public String editPatient(@PathVariable("id") Long id, Model model) {
        Patient patients = patientService.getPatient(id);
        List<BloodBank> bloodBanks = bloodBankService.getAllBloodBank();
        model.addAttribute("patients", patients);
        model.addAttribute("bloodBanks", bloodBanks);
        return "BBPatientEdit";
    }

    @PostMapping("/patients/edit/{id}")
    public String savePatient(@PathVariable("id") Long id, @ModelAttribute("patients") Patient patient, Model model) {
        Patient existingPatient = patientService.getPatient(id);
        if (existingPatient == null) {
            model.addAttribute("errorMessage", "Patient not found");
            return "redirect:/BBPatientEdit";
        }
        // Update the existing patient with the new details
        existingPatient.setName(patient.getName());
        existingPatient.setDOB(patient.getDOB());
        existingPatient.setPhone(patient.getPhone());
        existingPatient.setBloodGroup(patient.getBloodGroup());
        existingPatient.setCause(patient.getCause());
        existingPatient.setBloodBank(patient.getBloodBank());
        // Save the updated patient
        patientService.savePatient(existingPatient);
        return "redirect:/patients"; // Redirect to the list of patients or another appropriate page
    }

    @GetMapping("/patients/delete/{id}")
    public String deletePatient(@PathVariable("id") Long id) {
        patientService.deletePatient(id);
        return "redirect:/patients";
    }

    @PostMapping("/saveAppointment")
    public String saveAppointment(@ModelAttribute Appointment appointment) {
        appointmentService.saveAppointment(appointment);
        return "redirect:/appointments";
    }

    @GetMapping("/appointments")
    public String listAppointments(Model model) {
        List<Appointment> appointments = appointmentService.getAllAppointment();
        model.addAttribute("appointments", appointments);
        return "BBAppointment";
    }

    @GetMapping("/emp-logout")
    public String empLogout() {
        return "redirect:/emp-signin?logout";
    }

}
