package com.csc3402.lab.project.service;

import com.csc3402.lab.project.model.Certificate;
import com.csc3402.lab.project.repository.CertificateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CertificateServiceImpl implements CertificateService {

    @Autowired
    private CertificateRepository certificateRepository;

    @Override
    public List<Certificate> listAllCertificates() {
        return certificateRepository.findAll();
    }

    @Override
    public Certificate getCertificate(Long cert_id) {
        return certificateRepository.findById(cert_id).orElse(null);
    }

    @Override
    public Certificate saveCertificate(Certificate certificate) {
        return certificateRepository.save(certificate);
    }

    public void deleteCertificate(Long cert_id) {
        certificateRepository.deleteById(cert_id);
    }
}
