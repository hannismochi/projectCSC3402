package com.csc3402.lab.project.dto;

import java.util.Date;

public class DonorDto {
    private Long donorId;
    private String name;
    private String email;
    private String DOB;
    private String medCondi;
    private String bloodGroup;
    private String emergencyPhone;
    private String relationshipDonor;
    private String bagId;
    private int volumeCc;
    private Date dateDonated;
    private String location;

    // Getters and Setters

    public Long getDonorId() {
        return donorId;
    }

    public void setDonorId(Long donorId) {
        this.donorId = donorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getMedCondi() {
        return medCondi;
    }

    public void setMedCondi(String medCondi) {
        this.medCondi = medCondi;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getEmergencyPhone() {
        return emergencyPhone;
    }

    public void setEmergencyPhone(String emergencyPhone) {
        this.emergencyPhone = emergencyPhone;
    }

    public String getRelationshipDonor() {
        return relationshipDonor;
    }

    public void setRelationshipDonor(String relationshipDonor) {
        this.relationshipDonor = relationshipDonor;
    }

    public String getBagId() {
        return bagId;
    }

    public void setBagId(String bagId) {
        this.bagId = bagId;
    }

    public int getVolumeCc() {
        return volumeCc;
    }

    public void setVolumeCc(int volumeCc) {
        this.volumeCc = volumeCc;
    }

    public Date getDateDonated() {
        return dateDonated;
    }

    public void setDateDonated(Date dateDonated) {
        this.dateDonated = dateDonated;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "DonorDto{" +
                "donorId=" + donorId +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", DOB='" + DOB + '\'' +
                ", medCondi='" + medCondi + '\'' +
                ", bloodGroup='" + bloodGroup + '\'' +
                ", emergencyPhone='" + emergencyPhone + '\'' +
                ", relationshipDonor='" + relationshipDonor + '\'' +
                ", bagId='" + bagId + '\'' +
                ", volumeCc=" + volumeCc +
                ", dateDonated=" + dateDonated +
                ", location='" + location + '\'' +
                '}';
    }
}


