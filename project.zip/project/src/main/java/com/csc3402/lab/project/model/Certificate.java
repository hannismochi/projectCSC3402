package com.csc3402.lab.project.model;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "certificate")
public class Certificate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cert_id;
    private Date dateDonated;
    private String bagId;
    private int volumeCc;
    private String location;
    private String notes;

    @ManyToOne
    @JoinColumn(name = "donor_id")
    private Donor donor;

    public Certificate() {
    }

    public Certificate(Long cert_id, Date dateDonated, String bagId, int volumeCc, String location, String notes, Donor donor) {
        this.cert_id = cert_id;
        this.dateDonated = dateDonated;
        this.bagId = bagId;
        this.volumeCc = volumeCc;
        this.location = location;
        this.notes = notes;
        this.donor = donor;
    }

    public Long getCert_id() {
        return cert_id;
    }

    public void setCert_id(Long cert_id) {
        this.cert_id = cert_id;
    }

    public Date getDateDonated() {
        return dateDonated;
    }

    public void setDateDonated(Date dateDonated) {
        this.dateDonated = dateDonated;
    }

    public String getBagId() {
        return bagId;
    }

    public void setBagId(String bagId) {
        this.bagId = bagId;
    }

    public int getVolumeCc() {
        return volumeCc;
    }

    public void setVolumeCc(int volumeCc) {
        this.volumeCc = volumeCc;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Donor getDonor() {
        return donor;
    }

    public void setDonor(Donor donor) {
        this.donor = donor;
    }

    @Override
    public String toString() {
        return "Certificate{" +
                "cert_id=" + cert_id +
                ", dateDonated=" + dateDonated +
                ", bagId='" + bagId + '\'' +
                ", volumeCc=" + volumeCc +
                ", location='" + location + '\'' +
                ", notes='" + notes + '\'' +
                ", donor=" + donor +
                '}';
    }
}

