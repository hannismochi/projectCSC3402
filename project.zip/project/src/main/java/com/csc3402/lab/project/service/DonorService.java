package com.csc3402.lab.project.service;

import com.csc3402.lab.project.dto.DonorDto;
import com.csc3402.lab.project.model.Donor;

import java.util.List;

public interface DonorService {
    Donor findByEmail(String email);

    Donor saveDonor(Donor donor);

    List<Donor> listAllDonors();

    List<DonorDto> getDonorDto();

    Donor getDonor(Long donor_id);

    void deleteDonor(Long donor_id);
}
