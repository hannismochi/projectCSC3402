package com.csc3402.lab.project.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "donor")
public class Donor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long donor_id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String IC;

    @Column(nullable = false)
    private String phone;

    @Column(nullable = false)
    private String address;

    @Column(nullable = false)
    private String DOB;

    @Column(nullable = false)
    private String bloodGroup;

    @Column(nullable = false)
    private String medCondi;

    @Column(nullable = false)
    private String emergencyPhone;

    @Column(nullable = false)
    private String relationshipDonor;

    @OneToMany(mappedBy = "donor", cascade = CascadeType.ALL)
    private List<Certificate> certificate;

    public Donor() {
    }

    public Donor(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public Donor(Long donor_id, String name, String email, String password, String IC, String phone, String address, String DOB, String bloodGroup, String medCondi, String emergencyPhone, String relationshipDonor, List<Certificate> certificate, BloodBank bloodBank) {
        this.donor_id = donor_id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.IC = IC;
        this.phone = phone;
        this.address = address;
        this.DOB = DOB;
        this.bloodGroup = bloodGroup;
        this.medCondi = medCondi;
        this.emergencyPhone = emergencyPhone;
        this.relationshipDonor = relationshipDonor;
        this.certificate = certificate;
    }

    public Long getDonor_id() {
        return donor_id;
    }

    public void setDonor_id(Long donor_id) {
        this.donor_id = donor_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIC() {
        return IC;
    }

    public void setIC(String IC) {
        this.IC = IC;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getMedCondi() {
        return medCondi;
    }

    public void setMedCondi(String medCondi) {
        this.medCondi = medCondi;
    }

    public String getEmergencyPhone() {
        return emergencyPhone;
    }

    public void setEmergencyPhone(String emergencyPhone) {
        this.emergencyPhone = emergencyPhone;
    }

    public String getRelationshipDonor() {
        return relationshipDonor;
    }

    public void setRelationshipDonor(String relationshipDonor) {
        this.relationshipDonor = relationshipDonor;
    }

    public List<Certificate> getCertificate() {
        return certificate;
    }

    public void setCertificate(List<Certificate> certificate) {
        this.certificate = certificate;
    }

    @Override
    public String toString() {
        return "Donor{" +
                "donor_id=" + donor_id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", IC='" + IC + '\'' +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                ", DOB='" + DOB + '\'' +
                ", bloodGroup='" + bloodGroup + '\'' +
                ", medCondi='" + medCondi + '\'' +
                ", emergencyPhone='" + emergencyPhone + '\'' +
                ", relationshipDonor='" + relationshipDonor + '\'' +
                ", certificate=" + certificate +
                '}';
    }
}

