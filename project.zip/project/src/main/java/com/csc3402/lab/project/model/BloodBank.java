package com.csc3402.lab.project.model;

import jakarta.persistence.*;

import java.util.List;
import java.util.Set;

@Entity
@Table(name = "bloodbank")
public class BloodBank {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bloodbank_id;
    private String name;
    private String address;
    private int phone;
    private String established_year;

    @OneToMany(mappedBy = "bloodBank")
    private Set<Patient> patient;

    public BloodBank() {
    }

    public Long getBloodbank_id() {
        return bloodbank_id;
    }

    public void setBloodbank_id(Long bloodbank_id) {
        this.bloodbank_id = bloodbank_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getEstablished_year() {
        return established_year;
    }

    public void setEstablished_year(String established_year) {
        this.established_year = established_year;
    }

    public Set<Patient> getPatient() {
        return patient;
    }

    public void setPatient(Set<Patient> patient) {
        this.patient = patient;
    }

    @Override
    public String toString() {
        return "BloodBank{" +
                "bloodbank_id=" + bloodbank_id +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", phone=" + phone +
                ", established_year='" + established_year + '\'' +
                ", patient=" + patient +
                '}';
    }
}
