package com.csc3402.lab.project.service;

import com.csc3402.lab.project.model.BloodBank;
import com.csc3402.lab.project.repository.BloodBankRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BloodBankServiceImpl implements BloodBankService {

    @Autowired
    private BloodBankRepository bloodBankRepository;

    public List<BloodBank> getAllBloodBank() {
        return bloodBankRepository.findAll();
    }

    public BloodBank getBloodBank(Long bloodbank_id) {
        return bloodBankRepository.findById(bloodbank_id).orElse(null);
    }

    public void saveEvent(BloodBank bloodBank) {
        bloodBankRepository.save(bloodBank);
    }

    public void deleteEvent(Long bloodbank_id) {
        bloodBankRepository.deleteById(bloodbank_id);
    }
}
