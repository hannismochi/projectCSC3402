package com.csc3402.lab.project.service;

import com.csc3402.lab.project.model.BloodBank;

import java.util.List;

public interface BloodBankService {

    List<BloodBank> getAllBloodBank();
}
