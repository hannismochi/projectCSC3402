package com.csc3402.lab.project.service;

import com.csc3402.lab.project.model.Certificate;

import java.util.List;

public interface CertificateService {
    List<Certificate> listAllCertificates();

    Certificate getCertificate(Long cert_id);

    Certificate saveCertificate(Certificate certificate);
}
