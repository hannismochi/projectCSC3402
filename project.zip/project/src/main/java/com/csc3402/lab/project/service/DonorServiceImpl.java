package com.csc3402.lab.project.service;
import com.csc3402.lab.project.dto.DonorDto;
import com.csc3402.lab.project.model.Certificate;
import com.csc3402.lab.project.model.Donor;
import com.csc3402.lab.project.repository.DonorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DonorServiceImpl implements DonorService {
    @Autowired
    private DonorRepository donorRepository;

    @Override
    public Donor findByEmail(String email) {
        return donorRepository.findByEmail(email);
    }

    public List<Donor> listAllDonors() {
        return donorRepository.findAll();
    }

    public Donor getDonor(Long id) {
        return donorRepository.findById(id).orElse(null);
    }

    @Override
    public Donor saveDonor(Donor donor) {
        return donorRepository.save(donor);
    }

    public void deleteDonor(Long id) {
        donorRepository.deleteById(id);
    }

    @Override
    public List<DonorDto> getDonorDto() {
        List<Donor> donors = donorRepository.findAll();
        List<DonorDto> donorDto = new ArrayList<>();

        for (Donor donor : donors) {
            DonorDto dto = new DonorDto();
            dto.setDonorId(donor.getDonor_id());
            dto.setName(donor.getName());
            dto.setEmail(donor.getEmail());
            dto.setDOB(donor.getDOB());
            dto.setMedCondi(donor.getMedCondi());
            dto.setBloodGroup(donor.getBloodGroup());
            dto.setEmergencyPhone(donor.getEmergencyPhone());
            dto.setRelationshipDonor(donor.getRelationshipDonor());

            if (!donor.getCertificate().isEmpty()) {
                Certificate certificate = donor.getCertificate().get(0);
                dto.setBagId(certificate.getBagId());
                dto.setVolumeCc(certificate.getVolumeCc());
                dto.setDateDonated(certificate.getDateDonated());
                dto.setLocation(certificate.getLocation());
            }
            donorDto.add(dto);
        }
        return donorDto;
    }

}
